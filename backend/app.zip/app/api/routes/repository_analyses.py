from __future__ import annotations

import uuid
from typing import Annotated

from fastapi import APIRouter, HTTPException, Query, status

from app.api.deps import CurrentUser, SessionDep
from app.models import (
    RepositoryAnalysisTaskCreate,
    RepositoryAnalysisTaskPublic,
    RepositoryAnalysisTasksPublic,
)
from app.services.github_repository_reference import (
    InvalidGitHubRepositoryUrlError,
    parse_public_github_repository_url,
)
from app.services.repository_analysis_task import (
    create_repository_analysis_task,
    get_repository_analysis_task_detail,
    list_repository_analysis_tasks,
    save_repository_analysis_task,
    serialize_repository_analysis_task_detail,
)


router = APIRouter(
    prefix="/repository-analyses",
    tags=["repository-analyses"],
)


@router.post(
    "",
    response_model=RepositoryAnalysisTaskPublic,
    status_code=status.HTTP_202_ACCEPTED,
)
def create_repository_analysis(
    request: RepositoryAnalysisTaskCreate,
    session: SessionDep,
    current_user: CurrentUser,
) -> RepositoryAnalysisTaskPublic:
    """
    创建公开 GitHub 仓库快速概览任务。

    这里只创建 queued 任务，不在 HTTP 请求中执行仓库分析。
    """

    try:
        repository = parse_public_github_repository_url(
            request.repository_url,
        )

        task = create_repository_analysis_task(
            session=session,
            owner_id=current_user.id,
            request=request,
            repository=repository,
        )
    except InvalidGitHubRepositoryUrlError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={
                "code": "INVALID_GITHUB_REPOSITORY_URL",
                "message": str(exc),
            },
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={
                "code": "INVALID_REPOSITORY_ANALYSIS_REQUEST",
                "message": str(exc),
            },
        ) from exc

    return serialize_repository_analysis_task_detail(task)


@router.get(
    "",
    response_model=RepositoryAnalysisTasksPublic,
)
def read_repository_analyses(
    session: SessionDep,
    current_user: CurrentUser,
    skip: Annotated[
        int,
        Query(ge=0),
    ] = 0,
    limit: Annotated[
        int,
        Query(ge=1, le=100),
    ] = 20,
    task_status: Annotated[
        str | None,
        Query(alias="status"),
    ] = None,
) -> RepositoryAnalysisTasksPublic:
    """
    分页查询当前登录用户的仓库分析任务。

    status 可选值：
    queued、running、completed、failed、expired。
    """

    try:
        return list_repository_analysis_tasks(
            session=session,
            owner_id=current_user.id,
            skip=skip,
            limit=limit,
            status=task_status,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={
                "code": "INVALID_REPOSITORY_ANALYSIS_FILTER",
                "message": str(exc),
            },
        ) from exc


@router.get(
    "/{task_id}",
    response_model=RepositoryAnalysisTaskPublic,
)
def read_repository_analysis(
    task_id: uuid.UUID,
    session: SessionDep,
    current_user: CurrentUser,
) -> RepositoryAnalysisTaskPublic:
    """
    查询当前用户的一条仓库分析任务详情。
    """

    task = get_repository_analysis_task_detail(
        session=session,
        owner_id=current_user.id,
        task_id=task_id,
    )

    if task is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "REPOSITORY_ANALYSIS_NOT_FOUND",
                "message": "Repository analysis task was not found",
            },
        )

    return task


@router.post(
    "/{task_id}/save",
    response_model=RepositoryAnalysisTaskPublic,
)
def save_repository_analysis(
    task_id: uuid.UUID,
    session: SessionDep,
    current_user: CurrentUser,
) -> RepositoryAnalysisTaskPublic:
    """
    将完成的临时仓库概览保存为长期记录。
    """

    try:
        task = save_repository_analysis_task(
            session=session,
            owner_id=current_user.id,
            task_id=task_id,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "REPOSITORY_ANALYSIS_NOT_COMPLETED",
                "message": str(exc),
            },
        ) from exc

    if task is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "REPOSITORY_ANALYSIS_NOT_FOUND",
                "message": "Repository analysis task was not found",
            },
        )

    return serialize_repository_analysis_task_detail(task)