import { useCallback, useState } from "react"

import type { RepositoryAnalysisTaskPublic } from "@/client"

import { RepositoryAnalysisCreateForm } from "./RepositoryAnalysisCreateForm"
import {
  type RepositoryAnalysisDetailTab,
  RepositoryAnalysisTaskDetail,
} from "./RepositoryAnalysisTaskDetail"
import { RepositoryAnalysisTaskList } from "./RepositoryAnalysisTaskList"

export function RepositoryAnalysisWorkbench() {
  const [selectedTaskId, setSelectedTaskId] =
    useState<string | null>(null)

  const [activeTab, setActiveTab] =
    useState<RepositoryAnalysisDetailTab>("progress")

  const handleSelectTask = useCallback((taskId: string) => {
    setSelectedTaskId(taskId)
    setActiveTab("progress")
  }, [])

  const handleTaskCreated = useCallback(
    (task: RepositoryAnalysisTaskPublic) => {
      handleSelectTask(task.id)
    },
    [handleSelectTask],
  )

  return (
    <div className="space-y-6">
      <PageHeader />

      <RepositoryAnalysisCreateForm
        onCreated={handleTaskCreated}
      />

      <div className="grid gap-6 lg:grid-cols-[20rem_minmax(0,1fr)]">
        <RepositoryAnalysisTaskList
          selectedTaskId={selectedTaskId}
          onSelectTask={handleSelectTask}
        />

        <RepositoryAnalysisTaskDetail
          selectedTaskId={selectedTaskId}
          activeTab={activeTab}
          onActiveTabChange={setActiveTab}
        />
      </div>
    </div>
  )
}

function PageHeader() {
  return (
    <div className="space-y-2">
      <h1 className="text-2xl font-semibold tracking-tight">
        GitHub 仓库分析
      </h1>

      <p className="max-w-3xl text-sm text-muted-foreground">
        提交公开 GitHub 仓库，后台将解析固定 Commit、
        扫描项目结构、分析前后端流程，并生成带 Evidence
        的仓库概览报告。
      </p>
    </div>
  )
}